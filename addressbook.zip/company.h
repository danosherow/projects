/******************************
*Date: 2023/07/25
*company.h
******************************/
#ifndef UNTITLED26_COMPANY_H
#define UNTITLED26_COMPANY_H

#include "contact.h"

class Company : public Contact {
public:
    Company();

    explicit Company(string);

    virtual ~Company();

    void print();

    static void test();

private:
};

#endif //UNTITLED26_COMPANY_H
