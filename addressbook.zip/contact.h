/******************************
*Date: 2023/07/25
*contact.h
******************************/
#ifndef UNTITLED26_CONTACT_H
#define UNTITLED26_CONTACT_H

#include <vector>
#include "contactelement.h"
#include "emailaddress.h"
#include "webaddress.h"
#include "phonenumber.h"

class Contact : public ContactElement {
private:
    int elementsSize;
    string name;
    vector<ContactElement> elements;
public:
    Contact();

    Contact(string);

    virtual ~Contact();

    void addContactElement(string);

    void deleteContactElement(string);

    string getName();

    int getElementsSize();

    string getAddress(int);

    void print();

    static void test();

    void playground();
};

#endif //UNTITLED26_CONTACT_H
