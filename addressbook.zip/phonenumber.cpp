/******************************
*Date: 2023/07/25
*phonenumber.cpp
******************************/
#include "phonenumber.h"

PhoneNumber::PhoneNumber() : ContactElement() {
}

PhoneNumber::PhoneNumber(string address) : ContactElement(address) {
}

PhoneNumber::~PhoneNumber() {

}

void PhoneNumber::print() {
    cout << getAddress() << endl;
}

void PhoneNumber::test() {
    PhoneNumber TestAddress("3215478932");
    //print()
    TestAddress.print();
}