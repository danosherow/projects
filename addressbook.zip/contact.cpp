/******************************
*Date: 2023/07/25
*contact.cpp
******************************/
#include <cstring>
#include <fstream>
#include "contact.h"

Contact::Contact() {
}

Contact::Contact(string name) : ContactElement() {
    elementsSize = 0;
    this->name = name;
}

Contact::~Contact() {
}

void Contact::addContactElement(string address) {
    string at, https;
    at = "@";
    https = "https://";
    size_t aFound = address.find(at);
    size_t hFound = address.find(https);
    if (aFound != address.npos) {
        EmailAddress NewEmail(address);
        elements.push_back(NewEmail);
        elementsSize++;
    } else if (hFound != address.npos) {
        WebAddress NewWebsite(address);
        elements.push_back(NewWebsite);
        elementsSize++;
    } else if (stof(address) != 0) {
        PhoneNumber NewPhoneNumber(address);
        elements.push_back(NewPhoneNumber);
        elementsSize++;
    } else
        throw InvalidContactElementException();
}


void Contact::deleteContactElement(string address) {
    string thisAddress;
    ContactElement tempAddress;
    int i = 0, found = 1;
    do {
        thisAddress = elements[i].getAddress();
        found = thisAddress.compare(address);
        i++;
    } while (i < elementsSize && found != 0);
    i--;
    if (found == 0) {
        tempAddress = elements[elementsSize - 1];
        elements[elementsSize - 1] = elements[i];
        elements[i] = tempAddress;
        elements.pop_back();
        elementsSize--;
    } else
        throw InvalidContactElementException();
}

string Contact::getName() {
    return name;
}

int Contact::getElementsSize() {
    return elementsSize;
}

string Contact::getAddress(int i) {
    return elements[i].getAddress();
}


void Contact::print() {
    cout << "Contact name: " << name << endl
         << "elementsSize: " << elementsSize << endl;

    for (int e = 0; e < elementsSize; e++)
        elements[e].print();
}

void Contact::test() {
    Contact TestContact("DanOsherow");
    //addContactElement()
    TestContact.addContactElement("https://www.google.com");
    TestContact.addContactElement("3245678979");
    TestContact.addContactElement("danosh@comcast.net");
    TestContact.addContactElement("https://www.yahoo.com");
    //getElementSize
    cout << TestContact.getElementsSize() << endl;
    //print()
    TestContact.print();
    //deleteContactElement()
    TestContact.deleteContactElement("https://www.google.com");
    //getAddress()
    cout << TestContact.elements[0].getAddress() << endl;
    //getName()
    cout << TestContact.getName() << endl;
    TestContact.print();

}