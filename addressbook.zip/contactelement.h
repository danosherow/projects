/******************************
*Date: 2023/07/25
*contactelement.h
******************************/
#ifndef UNTITLED26_CONTACTELEMENT_H
#define UNTITLED26_CONTACTELEMENT_H

#include <iostream>
#include <string>
#include "addressbookexceptions.h"

using namespace std;

class ContactElement {
private:
    string address;
public:
    ContactElement();

    explicit ContactElement(string);

    virtual ~ContactElement();

    string getAddress();

    void print();

    static void test();
};

#endif //UNTITLED26_CONTACTELEMENT_H
