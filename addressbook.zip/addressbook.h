/******************************
*Date: 2023/07/25
*addressbook.h
******************************/
#ifndef UNTITLED26_ADDRESSBOOK_H
#define UNTITLED26_ADDRESSBOOK_H

#include "contact.h"
#include "person.h"
#include "company.h"

class AddressBook : public Contact {
private:
    int size;
    string bookName;
    vector<Contact> contacts;
public:
    AddressBook();

    AddressBook(string);

    virtual ~AddressBook();

    Contact *searchContact(string);

    void save(string);

    void load(string);

    void addContact(string);

    void deleteContact(string);

    void addContactElement(string, string);

    void deleteContactElement(string, string);

    void print();

    static void test();

    void process();

    int menu();

};

#endif //UNTITLED26_ADDRESSBOOK_H
