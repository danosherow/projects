/******************************
*Date: 2023/07/25
*webaddress.cpp
******************************/
#include "webaddress.h"

WebAddress::WebAddress() {

}

WebAddress::WebAddress(string address) : ContactElement(address) {
}

WebAddress::~WebAddress() {
}

void WebAddress::print() {
    cout << getAddress() << endl;
}

void WebAddress::test() {
    WebAddress TestAddress("https://www.google.com");
    //print()
    TestAddress.print();
}