/******************************
*Date: 2023/07/25
*person.cpp
******************************/
#include "person.h"

Person::Person() {
}

Person::Person(string name) : Contact(name) {
}

Person::~Person() {
}

void Person::print() {
    cout << getName() << endl;
}

void Person::test() {
    Person TestPerson("Sasquatch");
    TestPerson.print();
}
