/******************************
*Date: 2023/07/25
*person.h
******************************/
#ifndef UNTITLED26_PERSON_H
#define UNTITLED26_PERSON_H

#include "contact.h"

class Person : public Contact {
public:
    Person();

    explicit Person(string);

    virtual ~Person();

    void print();

    static void test();

private:
};

#endif //UNTITLED26_PERSON_H
