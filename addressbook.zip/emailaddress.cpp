/******************************
*Date: 2023/07/25
*emailaddress.cpp
******************************/
#include "emailaddress.h"

EmailAddress::EmailAddress() : ContactElement() {
}

EmailAddress::EmailAddress(string address) : ContactElement(address) {
}

EmailAddress::~EmailAddress() {
}

void EmailAddress::print() {
    cout << getAddress() << endl;
}

void EmailAddress::test() {
    EmailAddress TestAddress("danosh@comcast.net");
    //print()
    TestAddress.print();
}