/******************************
*Date: 2023/07/25
*addressbookexceptions.h
******************************/

#ifndef UNTITLED26_ADDRESSBOOKEXCEPTIONS_H
#define UNTITLED26_ADDRESSBOOKEXCEPTIONS_H

#include <iostream>
#include <fstream>
#include <string>

using namespace std;

class CannotOpenFileException {
private:
    int errorCode;
    string message;
public:
    void print() {
        cerr << errorCode << ": " << message << endl;
    }

    CannotOpenFileException() {
        errorCode = 100100;
        message = "Specified file cannot be found and/or opened.\n";
    }

    virtual ~CannotOpenFileException() {}
};

class InvalidContactException {
private:
    int errorCode;
    string message;
public:
    void print() {
        cerr << errorCode << ": " << message << endl;
    }

    InvalidContactException() {
        errorCode = 123432;
        message = "The contact entered is an invalid entry.\n";
    }

    virtual ~InvalidContactException() {}
};

class InvalidContactElementException {
private:
    int errorCode;
    string message;
public:
    void print() {
        cerr << errorCode << ": " << message << endl;
    }

    InvalidContactElementException() {
        errorCode = 345654;
        message = "The contact element entered is an invalid entry.\n";
    }

    virtual ~InvalidContactElementException() {}
};

#endif //UNTITLED26_ADDRESSBOOKEXCEPTIONS_H
