/******************************
*Date: 2023/07/25
*contactelement.cpp
******************************/
#include "contactelement.h"


ContactElement::ContactElement() {
}

ContactElement::ContactElement(string address) {
    this->address = address;
}

ContactElement::~ContactElement() {
}

string ContactElement::getAddress() {
    return address;
}


void ContactElement::print() {
    cout << address << endl;
}

void ContactElement::test() {
    //ContactElement()
    ContactElement TestElement("https://www.ebay.com");
    //getAddress()
    TestElement.getAddress();
    //print()
    TestElement.print();
}

