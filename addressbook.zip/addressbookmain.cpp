/******************************
*Date: 2023/07/25
*addressbookmain.cpp
******************************/
#include "addressbook.h"

int main() {
    try {
//        ContactElement::test();
//        EmailAddress::test();
//        WebAddress::test();
//        PhoneNumber::test();
//        Contact::test();
//        Person::test();
//        Company::test();
//        AddressBook::test();
        AddressBook DansAddressBook("Daniel");
        DansAddressBook.process();
    }
    catch (CannotOpenFileException &error) {
        error.print();
    }
    catch (InvalidContactException &error) {
        error.print();
    }
    catch (InvalidContactElementException &error) {
        error.print();
    }
    return 0;
}
