/******************************
*Date: 2023/07/25
*phonenumber.h
******************************/
#ifndef UNTITLED26_PHONENUMBER_H
#define UNTITLED26_PHONENUMBER_H

#include "contactelement.h"

class PhoneNumber : public ContactElement {
public:
    PhoneNumber();

    explicit PhoneNumber(string);

    virtual ~PhoneNumber();

    void print();

    static void test();

private:

};

#endif //UNTITLED26_PHONENUMBER_H
