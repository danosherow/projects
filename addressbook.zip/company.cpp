/******************************
*Date: 2023/07/25
*addressbook.cpp
******************************/
#include "company.h"

Company::Company() {
}

Company::Company(string name) : Contact(name) {
}

Company::~Company() {
}

void Company::print() {
    cout << getName() << endl;
}

void Company::test() {
    Company TestPerson("CORPMcdonalds");
    TestPerson.print();
}