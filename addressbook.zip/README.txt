/******************************
*Date: 2023/07/25
*README.txt
******************************/
//Must have file named useraddressbook.txt in directory to run program, I included my file in the zip.
To Compile addressbookmain:
>g++ -o addressbook addressbook.h addressbook.cpp addressbookmain.cpp addressbookexceptions.h company.h company.cpp
contact.h contact.cpp contactelement.h contactelement.cpp emailaddress.h emailaddress.cpp person.h person.cpp
phonenumber.h phonenumber.cpp webaddress.h webaddress.cpp
To Execute useraddressbook:
>addressbook
