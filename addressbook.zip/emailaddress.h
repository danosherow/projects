/******************************
*Date: 2023/07/25
*emailaddress.h
******************************/
#ifndef UNTITLED26_EMAILADDRESS_H
#define UNTITLED26_EMAILADDRESS_H

#include "contactelement.h"

class EmailAddress : public ContactElement {
public:
    EmailAddress();

    explicit EmailAddress(string);

    virtual ~EmailAddress();

    void print();

    static void test();

private:

};

#endif //UNTITLED26_EMAILADDRESS_H
