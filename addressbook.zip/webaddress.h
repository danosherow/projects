/******************************
*Date: 2023/07/25
*webaddress.h
******************************/
#ifndef UNTITLED26_WEBADDRESS_H
#define UNTITLED26_WEBADDRESS_H

#include "contactelement.h"

class WebAddress : public ContactElement {
public:
    WebAddress();

    explicit WebAddress(string);

    virtual ~WebAddress();

    void print();

    static void test();

private:

};

#endif //UNTITLED26_WEBADDRESS_H
