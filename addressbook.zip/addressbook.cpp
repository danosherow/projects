/******************************
*Date: 2023/07/25
*addressbook.cpp
******************************/
#include <fstream>
#include <cstdio>
#include "addressbook.h"

AddressBook::AddressBook() {
    size = 0;
}

AddressBook::AddressBook(string name) {
    size = 0;
    bookName = name;
}

AddressBook::~AddressBook() {
}

Contact *AddressBook::searchContact(string name) {
    Contact *foundContact;
    float found;
    int i = 0;
    do {
        string thisContact = contacts[i].getName();
        found = thisContact.compare(name);
        i++;
    } while (found != 0 && i < size);
    if (found == 0)
        foundContact = &contacts[i - 1];
    else
        throw InvalidContactException();

    return foundContact;
}

void AddressBook::save(string filename) {
    ofstream fout;
    string file = filename;
    fout.open(file);
    if (fout.is_open()) {
        fout << size << endl;
        for (int i = 0; i < size; i++) {
            fout << contacts[i].getName() << endl
                 << contacts[i].getElementsSize() << endl;
            for (int ie = 0; ie < contacts[i].getElementsSize(); ie++)
                fout << contacts[i].getAddress(ie) << endl;
        }
        fout.close();
    } else
        throw CannotOpenFileException();
}

void AddressBook::load(string filename) {
    int cSize, eSize;
    ifstream fin;
    string file = filename, contactName, elementName;
    fin.open(file);
    if (fin.is_open()) {
        fin >> cSize;
        for (int contactCount = 0; contactCount < cSize; contactCount++) {
            fin >> contactName;
            addContact(contactName);
            fin >> eSize;
            for (int eCount = 0; eCount < eSize; eCount++) {
                fin >> elementName;
                addContactElement(contactName, elementName);
            }
//

        }
        fin.close();
    } else
        throw CannotOpenFileException();
}

void AddressBook::addContact(string name) {
    string CORP = "CORP";
    size_t found = name.find(CORP);
    if (found != name.npos) {
        Contact NewContact(name);
        contacts.push_back(NewContact);
        size++;
    } else {
        Person NewPerson(name);
        contacts.push_back(NewPerson);
        size++;
    }
}

void AddressBook::deleteContact(string name) {
    Contact *ThisContact = searchContact(name);
    Contact placeHolder = *ThisContact;
    Contact placeHolder2 = contacts[size - 1];
    contacts[size - 1] = placeHolder;
    *ThisContact = placeHolder2;
    contacts.pop_back();
    size--;
}

void AddressBook::addContactElement(string name, string address) {
    Contact *ThisContact = searchContact(name);
    ThisContact->addContactElement(address);
}

void AddressBook::deleteContactElement(string name, string address) {
    Contact *ThisContact = searchContact(name);
    ThisContact->deleteContactElement(address);
}

void AddressBook::print() {
    cout << "Address Book's name: " << bookName << endl;
    for (int i = 0; i < size; i++)
        contacts[i].print();
}

void AddressBook::test() {
    AddressBook TestBook("TestName");
    //menu()
    TestBook.menu();
    //addContact()
    TestBook.addContact("DanOsherow");
    cout << TestBook.contacts[0].getName() << endl;
    //searchContact()
    cout << TestBook.searchContact("DanOsherow") << endl;
    //addContactElement()
    TestBook.addContactElement("DanOsherow", "danosh@comcast.net");
    cout << TestBook.contacts[0].getAddress(0);
    TestBook.addContactElement("DanOsherow", "brianclincy@comcast.net");
    //deleteContactElement()
    TestBook.deleteContactElement("DanOsherow", "brianclincy@comcast.net");
    TestBook.print();
    TestBook.addContactElement("DanOsherow", "https://www.gilmanpools.com");
    TestBook.addContact("MattBoyle");
    cout << TestBook.contacts[1].getName() << endl;
    TestBook.addContactElement("MattBoyle", "mattboyle@comcast.net");
    TestBook.addContactElement("MattBoyle", "2672316305");
    TestBook.addContactElement("MattBoyle", "https://www.reedmantoll.com");
    TestBook.addContactElement("MattBoyle", "https://www.woodwork.com");
    cout << TestBook.contacts[0].getAddress(0) << endl;
    //print()
    TestBook.print();
    string testFile = "dan_osherow_address_book.txt";
    //save()
    TestBook.save(testFile);
    AddressBook NewTestBook;
    //load()
    NewTestBook.load(testFile);
    cout << NewTestBook.size << endl;
    cout << NewTestBook.contacts[0].getName() << endl;
    cout << NewTestBook.contacts[0].getElementsSize() << endl;
    //deleteContact()
    NewTestBook.deleteContact("DanOsherow");
    cout << NewTestBook.contacts[0].getName() << endl;
    NewTestBook.print();

    cout << "Testing Complete\n";
}

void AddressBook::process() {
    Contact TempContact;
    string contactName, elementName, at, https;
    at = "@";
    https = "https://";
    string addressBookFile = "useraddressbook.txt";
    load(addressBookFile);
    cout << "Hello " << bookName << "! Welcome to your Digital Address Book!\n";
    int userChoice = menu(), elementMenu, esize;
    while (userChoice != 9) {
        switch (userChoice) {
            case 1:
                cout << "Enter the contact's name you are searching for.\n"
                     << "Be sure to capitalize the first letter of the first and last name.\n"
                     << "Do not put any spaces in the name:\n";
                cin >> contactName;
                TempContact = *searchContact(contactName);
                TempContact.print();
                userChoice = menu();
                break;
            case 2:
                cout << "Enter the contact's name you would like to add.\n"
                     << "If the contact is a business type BIZ before tha name, with no space between.\n"
                     << "Be sure to capitalize the first letter of the first and last name.\n"
                     << "Do not put any spaces in the name:\n";
                cin >> contactName;
                addContact(contactName);
                save(addressBookFile);
                userChoice = menu();
                break;
            case 3:
                cout << "Enter the contact's name you want to delete.\n"
                     << "Be sure to capitalize the first letter of the first and last name.\n"
                     << "Do not put any spaces in the name:\n";
                cin >> contactName;
                deleteContact(contactName);
                save(addressBookFile);
                userChoice = menu();
                break;
            case 4:
                cout << "Enter the contact's name you want to add a contact element to.\n"
                     << "Be sure to capitalize the first letter of the first and last name.\n"
                     << "Do not put any spaces in the name:\n";
                cin >> contactName;
                cout << "Please enter the contact element with the correct format:\n"
                     << "Phone Number ex: 7052223344\n"
                     << "Email ex: danosh@aol.com\n"
                     << "Website ex: https://www.gilmanpools.com\n";
                cin >> elementName;
                addContactElement(contactName, elementName);
                save(addressBookFile);
                userChoice = menu();
                break;
            case 5:
                cout << "Enter the contact's name you want to delete a contact element from.\n"
                     << "Be sure to capitalize the first letter of the first and last name.\n"
                     << "Do not put any spaces in the name:\n";
                cin >> contactName;
                cout << "Please enter the contact element with the correct format:\n"
                     << "Phone Number ex: 7052223344\n"
                     << "Email ex: danosh@aol.com\n"
                     << "Website ex: https://www.gilmanpools.com\n";
                cin >> elementName;
                deleteContactElement(contactName, elementName);
                save(addressBookFile);
                userChoice = menu();
                break;
            case 6:
                cout << "Enter the contact's name you want to print an element from.\n"
                     << "Be sure to capitalize the first letter of the first and last name.\n"
                     << "Do not put any spaces in the name:\n";
                cin >> contactName;
                TempContact = *searchContact(contactName);
                cout << "Which contact elements would you like to print?\n"
                     << "Enter the number associated with your selection)\n"
                     << "1) Emails\n2) Websites\n3) Numbers\n";
                cin >> elementMenu;
                switch (elementMenu) {
                    case 1:
                        for (int i = 0; i < TempContact.getElementsSize(); i++) {
                            string thisElement = TempContact.getAddress(i);
                            size_t aFound = thisElement.find(at);
                            if (aFound != thisElement.npos)
                                cout << thisElement << endl;
                            else
                                continue;
                        }
                        break;
                    case 2:
                        for (int i = 0; i < TempContact.getElementsSize(); i++) {
                            string thisElement = TempContact.getAddress(i);
                            size_t hFound = thisElement.find(https);
                            if (hFound != thisElement.npos)
                                cout << thisElement << endl;
                            else
                                continue;
                        }
                        break;
                    case 3:
                        for (int i = 0; i < TempContact.getElementsSize(); i++) {
                            string thisElement = TempContact.getAddress(i);
                            if (thisElement.npos != thisElement.find_first_of("0123456789"))
                                cout << thisElement << endl;
                            else
                                continue;
                        }
                        break;
                    default:
                        throw InvalidContactException();
                }
                userChoice = menu();
                break;
            case 7:
                cout << "Enter the contact's name whose information you want to print.\n"
                     << "Be sure to capitalize the first letter of the first and last name.\n"
                     << "Do not put any spaces in the name:\n";
                cin >> contactName;
                TempContact = *searchContact(contactName);
                TempContact.print();
                userChoice = menu();
                break;
            case 8:
                print();
                userChoice = menu();
                break;
            case 9:
                return;
            default:
                cout << "Please choose a valid menu selection.\n";
                userChoice = menu();
                break;
        }
    }
//    save(addressBookFile);
}

int AddressBook::menu() {
    cout << "Enter the number associated with the action you want to take:\n"
         << "1) Search for a contact\n"
         << "2) Add contact\n"
         << "3) Delete contact\n"
         << "4) Add contact element for a specific contact\n"
         << "5) Delete contact element for a specific contact\n"
         << "6) Print a Contact Element of a Contact\n"
         << "7) Print a Contact\n"
         << "8) Print the Entire Address Book\n"
         << "9) Exit\n";
    int menuOption;
    cin >> menuOption;
    return menuOption;
}